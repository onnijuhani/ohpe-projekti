import random

#avataan tallennus
try:
    with open(f"Tallennus.txt") as tt:
        for rivi in tt:
            pelit = int(rivi[2])
            voitot = int(rivi[7])
            häviöt= int(rivi[12])
except:
    pelit = 0
    voitot = 0
    häviöt = 0
    

def luo_nopat(määrä: int) -> list:
    """
    #funktio noppien luonnille
    """
    noppa = list(range(1,7))
    nopat = []
    x = 0
    while True:
        if x == määrä:
            break
        nopat.append(list(noppa))
        x += 1
    return(nopat)


def sekoita_nopat(nopat: list) -> list:
    """
    #funktio sekoittaa ja jakaa nopat
    """
    for kaikki in nopat:
        random.shuffle(kaikki)
    lista = []
    for i in nopat:
        lista.append(i[1])        
    return(lista)    


def etsimerkki(mistä: list, mitä) -> int:
    """
    #funktio joka laskee tietyn merkin määrän listassa
    """
    summa = 0
    kohta = 0
    while True:
        if mistä[kohta] == mitä:
            summa += 1
            kohta += 1
        else:
            kohta += 1        
        if kohta == len(mistä):
            break
    return(summa)   


def kone_aloittaa(tietokone: list, cheat: list,taso: int) -> tuple:
    """
    #koneen mahdollisia aloituksia
    """
    while True:
        x = 1
        while True:
            if x == 7:
                break
            vastaus = ""
            if etsimerkki(cheat,x) > taso+2:
                arpa = [1,2,2]
                arpa2 = [1,2,3,4,5,6]
                random.shuffle(arpa)
                random.shuffle(arpa2)
                if arpa2[0] < 3:
                    vastaus = tuple((arpa[0],arpa2[0]))
                elif arpa2[0] == 3:
                    vastaus = tuple((etsimerkki(tietokone,x),x))
                else:
                    vastaus = tuple((arpa[0],x))
                break
            x += 1
        if vastaus == "":
            if tietokone[4] > 3:
                vastaus = tuple((1,tietokone[4]))
        if vastaus == "":
            rand = list([1,2,3,1,4,5,6])
            kerroin = [1,2,3,1,1,2]
            random.shuffle(rand)
            random.shuffle(kerroin)
            vastaus = tuple((kerroin[0],rand[0]))
        if vastaus[0] > etsimerkki(cheat,vastaus[1]):
            rand = list([1,2,3,1,2,3,4,5,6])
            random.shuffle(rand)
            if rand[0] < 5:
                vastaus = ((1,rand[2]))
        return(vastaus)
        break
    

def syöte_muoto(syöte: str) -> tuple:
    """
    #muokataan pelaajan syöte pelin vaatimaan muotoon
    """
    if syöte.find(" ") == -1 :
        return(False)
    if syöte.find(".") > 0 :
        return(False)
    if syöte[1] in ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","w","v","x","y","z","å","ö","ä"]:
        return(False)
    if syöte[1] == 1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 9 or 0:
        if int(syöte[0:2]) > 50:
            return False
        else:
            nop1 = int(syöte[0:2])
    else:
        nop1 = int(syöte[0])
    nop2 = int(syöte[-1])
    return(tuple((nop1,nop2)))

def testaa_vastaus(testaa: tuple, mihin: tuple, määrä: int) -> bool:
    """
    #testataan ettei pelaajan vastaus riko yhtäkään pelin sääntöä
    """
    if testaa == False:
        return(False)
    if testaa[0] < mihin[0]:
        return(False)
    if testaa[0] > 0 and testaa[0] < määrä*2+1:
        if testaa[1] > 0 and testaa[1] < 7:
            if testaa[1] == mihin[1]:
                if testaa[0] > mihin[0]:
                    return(True)
                else:
                    return(False)
                if testaa[0] <= mihin[0]:
                    return(False)
            elif testaa[1] > mihin[1]:
                return(True)
            elif testaa[0] > mihin[0]:
                return(True)
            elif testaa[0] < mihin[0]:
                return(False)
        else:
            return(False)
    else:
        return(False)

def tuloste_muoto(vastaus: tuple) -> str:
    """
    #funktio koneen vastauksien muodolle
    """
    return(f"{vastaus[0]} kertaa silmäluku {vastaus[1]}")

def omat_nopat(nopat: list, määrä: int) -> str:
    """
    #mallit noppien printtaukselle
    """
    if määrä == 6:
        return(f"{nopat[0]} | {nopat[1]} | {nopat[2]} | {nopat[3]} | {nopat[4]} | {nopat[5]}")
    elif määrä == 8:
        return(f"{nopat[0]} | {nopat[1]} | {nopat[2]} | {nopat[3]} | {nopat[4]} | {nopat[5]} | {nopat[6]} | {nopat[7]}")
    elif määrä == 10:
        return(f"{nopat[0]} | {nopat[1]} | {nopat[2]} | {nopat[3]} | {nopat[4]} | {nopat[5]} | {nopat[6]} | {nopat[7]} | {nopat[8]} | {nopat[9]}")

def pelaajan_vastaus(vastaus: str, valinta_t, määrä):
    """
    #tarkistetaan pelaajan syötteen virheet ja valitaan seuraava vaihe
    """
    if vastaus == "Vale" or vastaus == "vale" or vastaus == "vale!" or vastaus == "Vale!" or vastaus == "Valehtelija!":
        return("Pelaaja syyttää")
    else:
        while True:
            testi = syöte_muoto(vastaus)
            if testaa_vastaus(testi,valinta_t, määrä) == True:
                if testi[0] > 0 and testi[-1] < 10000000000000:
                    return(tuple(testi))
                else:
                    return("virhe")
            else:
                return("virhe")
            
    
def ensimmäinen_kierros(pelaaja: tuple, tietokone: tuple, nopat: list,cheat: list, taso: int, pelaajan_nopat:list):
    """
    #koneen mahdollisia vastauksia ensimmäiselle kierrokselle         
    """
    p_noppa = pelaaja[1]
    p_kerroin = pelaaja[0]
    omat = etsimerkki(nopat,p_noppa)
    yht = etsimerkki(cheat,p_noppa)
    määrä = p_kerroin - omat    
    arpa = [1,2,3,4,5,6]
    kerroin_arpa = [1,2,2,1,2,3]
    random.shuffle(arpa)
    random.shuffle(kerroin_arpa)    
    omat_jär = nopat_järjestykseen(nopat)
    cheat_jär = nopat_järjestykseen(cheat)
    vas_jär = nopat_järjestykseen(pelaajan_nopat)
    isoin_key_vas = vas_jär[0]
    isoin_key = omat_jär[0]
    isoin_key_määrä = omat_jär[1]
    isoin_key_kaikki = cheat_jär[0]
    isoin_key_määrä_kaikki = cheat_jär[1]
        
    if p_kerroin > omat and p_kerroin > taso+2:
        if p_kerroin > yht and p_kerroin > isoin_key_määrä:
            return("Tietokone syyttää")
        else:
            return((p_kerroin+1,isoin_key))
    if isoin_key_vas == p_noppa:
        if p_kerroin > isoin_key_määrä_kaikki:
            return("Tietokone syyttää")
        elif p_kerroin > taso:
            if p_noppa == 6:
                return((p_kerroin+1,isoin_key_vas))
            else:
                if p_noppa + 3 > 6:
                    return((p_kerroin+1,arpa[0]))
                else:
                    return((p_kerroin,p_noppa+kerroin_arpa[0]))
        elif p_noppa < isoin_key:
            return((p_kerroin,isoin_key))
        else:
            if kerroin_arpa[0] > 3:
                return((p_kerroin+kerroin_arpa[0],isoin_key))
            else:
                return((p_kerroin+1,arpa[1]))
    else:
        if arpa[0] < 4:
            if kerroin_arpa[0] > p_kerroin:
                return((kerroin_arpa[0],arpa[3]))
            else:
                return((p_kerroin+1,isoin_key_vas))
        else:
            if kerroin_arpa[0] > p_kerroin:
                return((kerroin_arpa[0],isoin_key_kaikki))
            else:
                return((p_kerroin+1,isoin_key))
    return((isoin_key_määrä+isoin_key_vas,p_noppa))
                    

def luo_dict(nopat) -> dict:
    """
    #funktio järjestää noppia dictionaryyn  
    """
    luvut = {}    
    for noppa in list(range(1,7)):
        luvut[noppa] = 0
        i = 0
        while i < len(nopat):
            luvut[noppa] = etsimerkki(nopat,noppa)
            i += 1
    return(luvut)        


def nopat_järjestykseen(lista: list) ->  tuple:
    """
    #funktio palauttaa hyödylliset arvot dictionarystä 
    """
    luvut = luo_dict(lista)                      
    isoin = 0
    isoin_key = 0
    for noppa in luvut:
        if luvut[noppa] > isoin:
            isoin = luvut[noppa]
            isoin_key = noppa        
    return((isoin_key,isoin))


def koneen_vastaus(pelaaja: tuple, tietokone: tuple, nopat: list, cheat: list, taso: int, kierros: int):
    """
    #koneen vastausfunktio, palauttaa vastauksen tai syytöksen
    """
    p_noppa = pelaaja[1]
    p_kerroin = pelaaja[0]
    omat = etsimerkki(nopat,p_noppa)
    yht = etsimerkki(cheat,p_noppa)
    määrä = p_kerroin - omat    
    arpa = [1,2,3,4,5,6]
    kerroin_arpa = [1,2,2,3]
    random.shuffle(arpa)
    random.shuffle(kerroin_arpa)
    
    omat_jär = nopat_järjestykseen(nopat)
    cheat_jär = nopat_järjestykseen(cheat)
    isoin_key = omat_jär[0]
    isoin_key_määrä = omat_jär[1]
    isoin_key_kaikki = cheat_jär[0]
    isoin_key_määrä_kaikki = cheat_jär[1]
    
    #erikoistilanteita
    if kierros > taso:
        if p_kerroin > isoin_key_määrä and p_noppa != isoin_key:
           return("Tietokone syyttää")
        if p_kerroin > isoin_key_määrä_kaikki and etsimerkki(nopat,p_noppa) <= taso:
           return("Tietokone syyttää")   
    if kierros < 2:
        if arpa[2] == 2:
            if p_noppa < 6:
                if p_kerroin < isoin_key_määrä_kaikki:
                    return((isoin_key_määrä_kaikki,isoin_key_kaikki))
    if isoin_key != isoin_key_kaikki:
        if p_kerroin < isoin_key_määrä_kaikki:
            return((p_kerroin+kerroin_arpa[1],isoin_key_kaikki))
    if arpa[0] < 4 and kierros > 2 and omat < 3:
        if p_kerroin > yht:
            return("Tietokone syyttää")
    if p_kerroin > len(nopat)/2 and p_kerroin >= isoin_key_määrä:
        return("Tietokone syyttää")
    if etsimerkki(cheat,arpa[5]) > p_kerroin:
        if arpa[5] > p_noppa:
            return((p_kerroin,arpa[5]))
        else:
            return((p_kerroin+1,arpa[5]))
    if etsimerkki(cheat,arpa[4]) > p_kerroin and kierros > 2:
        if arpa[4] > p_noppa:
            return((p_kerroin,arpa[4]))
        else:
            return((p_kerroin+1,arpa[4]))
        
     #pelaajan syöte suuri   
    if p_kerroin > yht and kierros > 0:       
        if arpa[0] <= 5:
            return("Tietokone syyttää")        
        elif arpa[0] <= 3:
            if p_noppa < isoin_key:
                return((p_kerroin,isoin_key_kaikki))
            else:
                return((p_kerroin+1,isoin_key))       
        else:
            return((p_kerroin+1,p_noppa))
      #pelaajan syöte pieni  
    if p_kerroin < yht:       
        if p_kerroin > etsimerkki(cheat,p_noppa):
            if etsimerkki(tietokone,p_noppa) >= taso+1:
                return("Tietokone syyttää")
        if p_kerroin > isoin_key_määrä:
            if arpa[0] < 6:
                return((p_kerroin+1,isoin_key_kaikki))
            else:
                return("Tietokone syyttää")
        elif p_kerroin == isoin_key_määrä:
            if p_noppa < isoin_key:
                return((p_kerroin,isoin_key))
            else:
                if p_noppa < 6:
                    return((p_kerroin,p_noppa+1))
                else:
                    return((p_kerroin+1,isoin_key_kaikki))
        elif p_kerroin < isoin_key_määrä:
            if p_noppa < isoin_key:
                return((p_kerroin,isoin_key))
            else:
                if p_noppa < 6:
                    return((p_kerroin,p_noppa+1))
                else:
                    return((p_kerroin+1,isoin_key))
        else:
            if kierros < 5:
                return((p_kerroin+1,arpa[4]))
            else:
                return((p_kerroin+1,isoin_key_kaikki))
    return((p_kerroin+1,arpa[0]))   

#pelin kuvaus ja ohjeet 
print("Pelaat peliä Liar's Dice\n")
print("Pelaat tietokonetta vastaan ja molemmille arvotaan sama määrä noppia. Näet itse vain omat noppasi.")
print("Pelin tarkoitus on arvata tietyn silmäluvun kokonaismäärä huomioiden omat ja vastustajan nopat.")
print("Voit korottaa kokonaismäärää tai silmälukua (Tai molempia). Voit myös syyttää vastustajaa valehtelusta.") 
print("Esim. Määrää korottamalla voit laskea silmälukua. Nostamalla silmälukua voit pitää määrän samana.\n")
print("Syötä vastaus muodossa: määrä kertaa silmäluku. esim: 5 kertaa 2. Syytä valehtelusta kirjoittamalla: vale\n")
input("Aloita painamalla enter  ")

#pelin ohjelma alkaa tästä
while True:
    
    #valitaan noppien määrä
    while True:
        määrä = input("Valitse noppien lukumäärä 6, 8 tai 10: ").strip()
        if määrä == "8" or määrä == "6" or määrä == "10":
            int(määrä)
            break
        else:
            print("Valitse kelvollinen määrä")
    print("\n")    
    määrä = int(määrä)
    
    #määritetään tärkeä muuttuja "taso" noppien määrän mukaan
    if määrä == 6:
        taso = 1
    elif määrä == 8:
        taso = 2
    elif määrä == 10:
        taso = 3
        
    # luodaan ja arvotaan nopat
    pelaaja = sekoita_nopat(luo_nopat(määrä))
    tietokone = sekoita_nopat(luo_nopat(määrä))
    tietokone1 = list(tietokone)
    for noppa in pelaaja[0:määrä-2]:
        tietokone1.append(noppa)
    print(f"Noppasi ovat: {omat_nopat(sorted(pelaaja),määrä)}\n")
    print("Peli alkaa!")
    
    #arvotaan aloittaja ja botin aloitusfunktio
    valinta_t = (0,0)
    if pelit == 0:
        valinta_t = kone_aloittaa(tietokone, tietokone1,taso)
        print(f"Vastustaja sanoo: {tuloste_muoto(valinta_t)}")
    else:
        if tietokone[0] <= 3:
            valinta_t = kone_aloittaa(tietokone, tietokone1,taso)
            print(f"Vastustaja sanoo: {tuloste_muoto(valinta_t)}")
        
    #tarvittavia muuttujia
    kierros = 0
    tulos = ""
    valinta_p = ""
    kierrosX = ""
    kierrosLoppu = ""

    #toistuvat kierrokset alkaa tästä
    while True:        
        if tulos != "":
            break
        
        #pelaajan vastaukset ja niiden tarkastus
        while True:
            while True:
                vastaus = input("Sinun vuorosi: ").strip()
                if vastaus == "vale" and kierros == 0 and tietokone[0] > 3:
                    print("Et voi syyttää valehtelusta vielä. Syötä noppien määrä")
                else:
                    break                    
            vastaus = pelaajan_vastaus(vastaus,valinta_t,määrä)
            if vastaus == "virhe":
                print("Korota joko määrää tai silmälukua tai syytä valehtelusta kirjoittamalla: vale. Max kerroin = noppien yhteismäärä, max silmäluku 6")
            else:
                break
        if vastaus == "Pelaaja syyttää":
            tulos = "Pelaaja syyttää"
            if kierros == 0:
                valinta_määrä = valinta_t[0]
            break
        else:
            valinta_p = vastaus
            
        valinta_silmäluku = valinta_p[1]
        valinta_määrä = valinta_p[0]            
        if tulos != "":
            break
        
        #koneen vastaus ensimmäiselle kierrokselle
        if kierros == 0 and määrä !=6:
            kierros1 = ensimmäinen_kierros(valinta_p,valinta_t, tietokone ,tietokone1 ,taso, pelaaja)        
            if kierros1 == "Tietokone syyttää":
                tulos = "Tietokone syyttää"
                break
            else:
                print(f"Vastustaja sanoo: {tuloste_muoto(kierros1)}")
                valinta_t = kierros1
                  
        #koneen kaikki loput kierrokset       
        if kierros > 0 or määrä == 6:
            kierrosX = koneen_vastaus(valinta_p,valinta_t, tietokone, tietokone1 ,taso, kierros)
            if kierrosX == "Tietokone syyttää":
                tulos = "Tietokone syyttää"
                break
            else:
                print(f"Vastustaja sanoo: {tuloste_muoto(kierrosX)}")
                valinta_t = kierrosX
                
        kierros += 1    # kierros siirtyy seuraavaan
                  
    # lasketaan nopat ja tulos
    kaikki_nopat = [pelaaja,tietokone]
    yhteensä = []
    y = 0
    while True:
        if y == 2:
            break
        x = 0
        while True:
            if x == len(pelaaja):
                break
            luku = kaikki_nopat[y][x]
            yhteensä.append(luku)
            x += 1
        y += 1

    # selvitetään ja tulostetaan voittaja
    if tulos == "Tietokone syyttää":
        if etsimerkki(yhteensä,valinta_silmäluku) >= valinta_määrä:
            input("Vastustaja sanoo: Valehtelija!   Paina enter...")
            print("\nVoitit pelin!")
            print(f"Silmälukuja {valinta_p[1]} on yhteensä {etsimerkki(yhteensä,valinta_p[1])} kpl")
            voitot +=1
        else:
            input("Vastustaja sanoo: Valehtelija!   Paina enter...")
            print("\nHävisit pelin!")
            print(f"Silmälukuja {valinta_p[1]} on yhteensä {etsimerkki(yhteensä,valinta_p[1])} kpl")
            häviöt +=1

    elif tulos == "Pelaaja syyttää":
        if etsimerkki(yhteensä,valinta_t[1]) >= valinta_t[0]:
            input("Syytät vastustajaa valehtelusta.   Paina enter...")
            print("\nHävisit pelin!")
            print(f"Silmälukuja {valinta_t[1]} on yhteensä {etsimerkki(yhteensä,valinta_t[1])} kpl")
            häviöt +=1
        else:
            input("Syytät vastustajaa valehtelusta.   Paina enter...")
            print("\nVoitit pelin!")
            print(f"Silmälukuja {valinta_t[1]} on yhteensä {etsimerkki(yhteensä,valinta_t[1])} kpl")
            voitot +=1
   
    print(f"Vastustajan nopat olivat: {omat_nopat(sorted(tietokone),määrä)}")

    # lasketaan kokonaispisteet ja peli alkaa alusta
    pelit += 1
    with open("Tallennus.txt","w") as t:
        sisältö = str((str(pelit),str(voitot),str(häviöt)))
        t.write(sisältö) 
    lopeta = input("\nKirjoita tähän lopeta tai paina enter jatkaaksesi ")
    print("\n")
    if lopeta == "lopeta":      
        break
    if pelit == 1:
        print(f"Pelattu {pelit} peli")
    else:
        print(f"Pelattu {pelit} peliä")
    print(f"Voitot: {voitot}\nHäviöt: {häviöt}\n")
    
    

    

